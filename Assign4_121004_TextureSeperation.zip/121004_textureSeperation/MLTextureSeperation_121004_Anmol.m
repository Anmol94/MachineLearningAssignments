im = double(imread('C:\Users\Anmol A\Desktop\texture.jpg'));

A = double(im(:,:,2:3));
rows = size(A,1);
cols = size(A,2);
A = reshape(A,rows*cols,2);

cluster = 4;
% repeat the clustering 3 times to avoid local minima
[cluster_idx, cluster_center] = kmeans(A,cluster,'distance','sqEuclidean', ...
                                      'Replicates',3);
 pixel_labels = reshape(cluster_idx,nrows,ncols);
segmented_images = cell(1,3);
rgb_label = repmat(pixel_labels,[1 1 3]);

for k = 1:cluster
    color = im;
    color(rgb_label ~= k) = 0;
    segmented_images{k} = color;
end
subplot(2, 2, 1);
imshow(segmented_images{1}), title('objects in cluster 1');
subplot(2, 2, 2);
imshow(segmented_images{2}), title('objects in cluster 2');
subplot(2, 2, 3);
imshow(segmented_images{3}), title('objects in cluster 3');
