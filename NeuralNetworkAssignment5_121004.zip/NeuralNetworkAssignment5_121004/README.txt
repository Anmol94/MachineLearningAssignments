ForwardNetwork and BackPropogate are the functions or toolbox tools developed for executing a neural network of choice.
Thus these two function files should be in the same folder as the NeuralNetwork.m for successful execution of NeuralNetwork.m

ToolBox Files:
ForwardNetwork and BackPropogate