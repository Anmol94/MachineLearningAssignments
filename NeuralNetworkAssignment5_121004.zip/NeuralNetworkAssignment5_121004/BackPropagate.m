function [weightCell, biasCell] = BackPropagate(rate, in, realOutput, sampleTarget, layer, weightCell, biasCell, layerOutputCells)
    LC = size(layer, 2);
    delta = cell(1, LC);
    D_weight = cell(1, LC);
    D_bias = cell(1, LC);
    %---From Output layer, it has different formula
    output = layerOutputCells{LC};
    delta{LC} = output .* (1-output) .* (sampleTarget - output);
    preoutput = layerOutputCells{LC-1};
    D_weight{LC} = rate .* preoutput' * delta{LC};
    D_bias{LC} = rate .* delta{LC};
    %---Back propagate for Hidden layers
    for layerIndex = LC-1:-1:1
        output = layerOutputCells{layerIndex};
        if layerIndex == 1
            preoutput = in;
        else
            preoutput = layerOutputCells{layerIndex-1};
        end
        weight = weightCell{layerIndex+1};
        sumup = (weight * delta{layerIndex+1}')';
        delta{layerIndex} = output .* (1 - output) .* sumup;
        D_weight{layerIndex} = rate .* preoutput' * delta{layerIndex};
        D_bias{layerIndex} = rate .* delta{layerIndex};
    end
    %---Update weightCell and biasCell
    for layerIndex = 1:LC
        weightCell{layerIndex} = weightCell{layerIndex} + D_weight{layerIndex};
        biasCell{layerIndex} = biasCell{layerIndex} + D_bias{layerIndex};
    end
end