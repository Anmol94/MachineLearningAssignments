clc;
 %---Set training parameters
    iterations = 5000;
    errorThreshhold = 0.1;
    alpha = 0.5;
    %Hidden layer type
    hiddenNeurons = [3 2];
    
    %Training data in this case XOR
    Input = [0 0; 0 1; 1 0; 1 1];
    Output = [0; 1; 1; 1];
    testInp = Input;
    testOut = Output;
    
    % %---'And' training data
    % trainInp = [1 1; 1 0; 0 1; 0 0];
    % trainOut = [1; 0; 0; 0];
    % testInp = trainInp;
    % testRealOut = trainOut;
    assert(size(Input,1)==size(Output, 1),...
        'Counted different sets of input and output.');
    %---Initialize Network attributes
    inArgc = size(Input, 2);
    outArgc = size(Output, 2);
    trainsetCount = size(Input, 1);
    
    %---Add output layer
    layerOfNeurons = [hiddenNeurons, outArgc];
    layerCount = size(layerOfNeurons, 2);
    
    %---Weight and bias random range
    e = 1;
    b = -e;
    %---Set initial random weights
    weightCell = cell(1, layerCount);
    for i = 1:layerCount
        if i == 1
            weightCell{1} = unifrnd(b, e, inArgc,layerOfNeurons(1));
        else
            weightCell{i} = unifrnd(b, e, layerOfNeurons(i-1),layerOfNeurons(i));
        end
    end
    %---Set initial biases
    biasCell = cell(1, layerCount);
    for i = 1:layerCount
        biasCell{i} = unifrnd(b, e, 1, layerOfNeurons(i));
    end
 for iter = 1:iterations
        for i = 1:trainsetCount
            % choice = randi([1 trainsetCount]);
            choice = i;
            sampleIn = Input(choice, :);
            sampleTarget = Output(choice, :);
            [realOutput, layerOutputCells] = ForwardNetwork(sampleIn, layerOfNeurons, weightCell, biasCell);
            [weightCell, biasCell] = BackPropagate(alpha, sampleIn, realOutput, sampleTarget, layerOfNeurons, ...
                weightCell, biasCell, layerOutputCells);
        end
        
        error = zeros(trainsetCount, outArgc);
        for t = 1:trainsetCount
            [predict, layeroutput] = ForwardNetwork(Input(t, :), layerOfNeurons, weightCell, biasCell);
            p(t) = predict;
            error(t, : ) = predict - Output(t, :);
        end
        err(iter) = (sum(error.^2)/trainsetCount)^0.5;
        
        %---Stop if reach error threshold
        if err(iter) < errorThreshhold
            break;
        end
    end
    
    %--Test the trained network with a test set
    testsetCount = size(testInp, 1);
    error = zeros(testsetCount, outArgc);
    for t = 1:testsetCount
        [predict, layeroutput] = ForwardNetwork(testInp(t, :), layerOfNeurons, weightCell, biasCell);
        p(t) = predict;
        error(t, : ) = predict - testOut(t, :);
    end
    %---Print predictions
    
    a = testInp;
    b = testOut;
    op = p';
    x1_x2__pred_err = [a b op op-b]
    
    
